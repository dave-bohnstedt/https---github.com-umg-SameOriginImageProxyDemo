﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web.Http;

namespace TestApp.Controllers
{
	public class ProxyController : ApiController {
		//
		// GET: /Proxy/id

		public HttpResponseMessage Get(Guid id) {
			HttpResponseMessage httpResponseMessage = new HttpResponseMessage();
			httpResponseMessage.StatusCode = HttpStatusCode.InternalServerError;

			try {
				//This is the Staging Asset Owner ID - Production will be different
				string ao = "{AssetOwnerId goes here}";

				string uriFull = string.Format("https://aspen-stg.umusic.com/AspenImagePreviewService/DamsImagePreview/{0}?ao={1}", id, ao);
				HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(uriFull);

				httpRequest.Method = System.Net.WebRequestMethods.Http.Get;
				AddAuthorizationHeaderStaging(httpRequest);
				httpRequest.KeepAlive = true;


				//dwb - Must do this for https/SSL
				ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(ValidateFbCertificate);

				HttpWebResponse response = (HttpWebResponse)httpRequest.GetResponse();
				if(response.StatusCode == HttpStatusCode.OK)
				{
					WebHeaderCollection myWebHeaderCollection = response.Headers;

					for (int i = 0; i < myWebHeaderCollection.Count; i++) {
						String headerKey = myWebHeaderCollection.GetKey(i);
						if (!string.IsNullOrWhiteSpace(headerKey) && (headerKey.ToLowerInvariant() == "cache-control")) {
							string[] values = myWebHeaderCollection.GetValues(headerKey);
							if (values.Length == 2) {
								string headerVal = values[0] + ", " + values[1];
								httpResponseMessage.Headers.Add(headerKey, headerVal);
								break;
							}
						}
					}
					//httpResponseMessage.Content.Headers.ContentType = myWebHeaderCollection.
					httpResponseMessage.Content = new StreamContent(response.GetResponseStream());
					httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");


					httpResponseMessage.StatusCode = HttpStatusCode.OK;
				}
				else {
					httpResponseMessage.StatusCode = HttpStatusCode.NotFound;
				}
			}
			catch (Exception ex) {
				//Log.LogException(string.Format("path={0}", path), ex);
				throw ex;
			}

			return httpResponseMessage;
		}

		private void AddAuthorizationHeaderStaging(HttpWebRequest httpWebRequest) {
			//These credentials are temporary - Still waiting for HP to generate the correct ones
			string encodedCredentials = Base64Encode(string.Format("{0}:{1}", @"{Username goes here}", @"{Password goes here}"));
			string authHeaderValue = string.Format("Basic {0}", encodedCredentials);
			httpWebRequest.Headers.Add(HttpRequestHeader.Authorization, authHeaderValue);
		}

		private static string Base64Encode(string plainText) {
			byte[] plainTextBytes = System.Text.Encoding.ASCII.GetBytes(plainText);
			string encodedText = System.Convert.ToBase64String(plainTextBytes);
			return encodedText;
		}
		private static string Base64Decode(string base64EncodedData) {
			byte[] base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
			string plainText = System.Text.Encoding.ASCII.GetString(base64EncodedBytes);
			return plainText;
		}

		/// <summary>
		/// For SSL, we have to provide this callback, even if it only returns true.
		/// Per:
		/// http://therelentlessfrontend.com/2012/05/12/webrequest-getresponse-throwing-ssl-secure-channel-error/
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="certificate"></param>
		/// <param name="chain"></param>
		/// <param name="policyErrors"></param>
		/// <returns></returns>
		private static bool ValidateFbCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors policyErrors) {
			return true;
		}

	}
}
